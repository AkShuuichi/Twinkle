#include "chooselevelscene.h"
#include <QMenuBar>
#include <QPushButton>
#include<QPainter>
#include<QAction>
#include<QDebug>
#include "playone.h"
#include "playtwo.h"
#include <QMediaPlayer>
#include<config.h>


//构造
ChooseLevelScene::ChooseLevelScene(QWidget *parent) : QMainWindow(parent)
{
    //选择关卡的大小
    this->setFixedSize(QSize(1420,802));
    //左上角的小图标
    this->setWindowIcon(QPixmap(":/new/prefix1/bm/b4837f277966730c5e64c2ea6bfc9d2f.jpg") );
    //标题
    this->setWindowTitle("选择音乐场景");


        //放音乐
        startSound=new QMediaPlayer(this);
        startSound->setMedia(QUrl("qrc:/new/prefix1/bm/choosemusic.mp3"));
        startSound->setVolume(5000);  //音量
        startSound->play();



    //创建两个选择音乐的按钮：
    QPushButton *musicBtn1=new QPushButton(this);
    musicBtn1->resize(WIDTH/5,LENGTH/15);
    musicBtn1->move(WIDTH/2.5,LENGTH/2.8);
    musicBtn1->setText("命に嫌われている。");
    connect(musicBtn1,&QPushButton::clicked,[=](){
        //进入游戏场景
        startSound->pause();
        delete startSound;
        this->hide();
        p1=new playone();
        p1->show();

    });



    QPushButton *musicBtn2=new QPushButton(this);
    musicBtn2->resize(WIDTH/5,LENGTH/15);
    musicBtn2->move(WIDTH/2.5,LENGTH/1.8);
    musicBtn2->setText("我想了太多关于你的形容");
    connect(musicBtn2,&QPushButton::clicked,[=](){
        //进入游戏场景
        startSound->pause();
        this->hide();
        p2=new playtwo();
        p2->show();

    });

}

//关卡的背景设置，重写一个画图函数
void ChooseLevelScene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/new/prefix1/bm/_20210715174722.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pix);

}




