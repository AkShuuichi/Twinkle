#ifndef FLOWER_H
#define FLOWER_H

#include <QObject>
#include <QPixmap>

class Flower: public QObject
{
    int pixindex;
    bool isStart;
    QPixmap pixes[3];
public:
     double x,y;
    Flower(double xx, double yy);
    ~Flower();
    void start();
    void draw(QPainter *);
protected:
    void timerEvent(QTimerEvent *);

};

#endif // FLOWER_H
