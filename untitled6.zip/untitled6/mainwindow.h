#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include<QPushButton>
#include <QMainWindow>
#include<QMovie>
#include<QLabel>
#include<QFont>
#include "chooselevelscene.h"
#include"config.h"
namespace Ui
{
class MainWindow;
}



class MainWindow : public QMainWindow
{
    Q_OBJECT

public:

    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
   ChooseLevelScene * chooseScene=NULL;
   void paintEvent(QPaintEvent *e);
     QPushButton *start,*exit;
     QLabel *label;
     void Label();
     QMediaPlayer *startSound3;


private slots:
     void Start();
     void Exit();
     void Choose();
};

#endif // MAINWINDOW_H
