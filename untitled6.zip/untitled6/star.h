#ifndef STAR_H
#define STAR_H

#include <QObject>
#include <QPixmap>

class Star : public QObject
{
    int pixindex;
    bool isStart;
    QPixmap pixes[3];
public:
    double x,y;
    Star(double xx, double yy);
    ~Star();
    void start();
    void draw(QPainter *);
protected:
    void timerEvent(QTimerEvent *);
};

#endif // STAR_H
