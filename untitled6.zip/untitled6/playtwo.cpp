#include "playtwo.h"
#include <QMenuBar>
#include<QPainter>
#include<QDebug>
#include "mainwindow.h"
#include<QPixmap>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<QObject>
#include<conio.h>
#include<QKeyEvent>
#include<QTimer>
#include <QMediaPlayer>
#include <QAction>
#include<QMenuBar>
#include"mypushbutton.h"
#include"config.h"
#include"chooselevelscene.h"
#include<QColor>
int Flag=1;
ChooseLevelScene *p4=NULL;
using namespace std;
const int HEIGHT=20;
const double v=30;
int score2;
int control=1;
int d2=0;
int w;
int j2=0;
int slide2=0;
class Note2
{
public:
    double x,y;
    int color,z,height;
    Note2(double a,double b,int d)
    {
        x=a;
        y=b;
        color=d;
    }
    Note2(){}
    ~Note2(){}
};
Note2 note2[COUNT2];


//函数:返回0-3的一个随机数
int setposition2()
{
    int pos=qrand()%4;//[(int)qrand() % 4]是一个从0到3的随机索引
    return pos;
}
playtwo::playtwo(QWidget *parent) : QMainWindow(parent)
{
    //界面的大小
    this->setFixedSize(QSize(WIDTH2,LENGTH));
    //左上角图标
    this->setWindowIcon(QPixmap(":/new/prefix1/bm/b4837f277966730c5e64c2ea6bfc9d2f.jpg") );
    //左上角标题
    this->setWindowTitle("音乐场景2");

    startSound2=new QMediaPlayer(this);
    startSound2->setMedia(QUrl("qrc:/new/prefix1/bm/xxr (2).mp3"));
    startSound2->setVolume(100);  //音量
    startSound2->play();

    srand(time(NULL));
    startTimer(70);

    //为每个对象的坐标赋值
    for(int i=0;i<COUNT2;i++)
    {
        int s=setposition2();//x是0~3的一个随机数
        note2[i].x=s*WIDTH/4;
         note2[i].z=s;
         note2[i].height=qrand()%40;
         note2[i].y=note2[i-1].y-v*7;
    }
flow1=new Flower(10,LENGTH*0.65);
    pro2=new QProgressBar(this);
    startSound4=new QMediaPlayer(this);
        QString sll = "QProgressBar::chunk:horizontal{background:rgb(60,94,225,200);}";
        pro2->setStyleSheet(sll);

        pro2->setRange(0,1375);
        pro2->setTextVisible(false);
        pro2->move(0,0);
        pro2->setFixedSize(WIDTH,LENGTH/40);
        pro2->show();
        QPushButton *backBtn2=new QPushButton(this);
        backBtn2->resize(150,100);
        backBtn2->move(left,bottom);
        backBtn2->setText("返回");
        connect(backBtn2,&QPushButton::clicked,[=](){
            //进入游戏场景
            this->hide();
            p4=new ChooseLevelScene();
            p4->show();
            startSound2->pause();
        });
}


//关卡的背景设置，重写一个画图函数
void playtwo::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/new/prefix1/bm/_20210715182008.jpg");
    painter.drawPixmap(0,0,WIDTH,LENGTH,pix);
    QFont font;
    font.setPixelSize(30);
    font.setBold(true);
    painter.setFont(font);
    painter.setPen(Qt::blue);
    QString str;
    str.sprintf("%d",score2);
    painter.drawText(left,top,str);
    str.sprintf("SCORE");
    painter.drawText(left,50,str);
    //画竖线
    flow1->draw(&painter);
    painter.setPen(Qt::white);
    for(int i=1;i<4;i++)
    {
        painter.drawLine(i*WIDTH/4,0,i*WIDTH/4,LENGTH);
    }
    painter.drawLine(0,LENGTH*0.75,WIDTH,LENGTH*0.75);
    if(control==1)
        {
          for(int i=1;i<=j2;i++)
             {
                note2[i].y+=v;
                QColor color("blue");
                color.setAlpha(100);
                 painter.setBrush(color);
                painter.drawRect(QRect(note2[i].x,note2[i].y,WIDTH/4,HEIGHT+note2[i].height));
             }
        }
     else
    {
        painter.setBrush(Qt::white);
        for(int i=1;i<=j2;i++)
            {
                if(i!=w)
                {
                    note2[i].y+=20;
                    if(note2[i].y>=0)
                       { QColor color("blue");
                        color.setAlpha(100);
                         painter.setBrush(color);
                   painter.drawRect(QRect(note2[i].x,note2[i].y,WIDTH/4,HEIGHT+note2[i].height));}
                    else {
                        continue;
                    }
                }
                 else
                {
                    QColor color("blue");
                    color.setAlpha(100);
                     painter.setBrush(color);
                     painter.drawRect(QRect(note2[w].x-WIDTH*2,note2[w].y+HEIGHT,WIDTH/4,note2[w].height));
                }
                control=1;
            }
    }
    if(note2[COUNT2-1].y>LENGTH||note2[COUNT2-1].x>WIDTH)
    {
        this->close();
        ending2=new ending();
        ending2->show();
        delete flow1;
        delete pro2;
        delete startSound4;
    }
}

void playtwo::timerEvent(QTimerEvent *)
{
    while(j2<COUNT2)
    {
        j2++;
        break;
    }
    slide2++;
        pro2->setValue(slide2);
    update();
}

void playtwo::nupdate()
{
    int i=1;
    for(;i<=COUNT2;i++)
    {
        if(note2[i].z==dirc)
        {
            if(note2[i].y>=LENGTH*0.65&&note2[i].y<LENGTH*0.85&&note2[i].x<WIDTH)
               {
                note2[i].x+=WIDTH*2;
                    w=i;
                    control=3;
                    startSound4->setMedia(QUrl("qrc:/new/prefix1/bm/boom.mp3"));
                    startSound4->setVolume(500);  //音量
                    startSound4->play();
                    flow1->start();
                    update();
                    score2++;

                }
        }
     }
}

void playtwo::keyPressEvent(QKeyEvent *event)//键盘事件
{

    QKeyEvent *key=(QKeyEvent*)event;
    switch(key->key())
    {
    case Qt::Key_A://消除第一个轨道上的小方块
    {
        dirc=0;
        flow1->x=WIDTH/8;
        nupdate();
        break;
    }
    case Qt::Key_S://消除第2个轨道上的小方块
    {
        dirc=1;
    flow1->x=3*WIDTH/8;
        nupdate();
        break;
    }
    case Qt::Key_D://消除第3个轨道上的小方块
    {
        dirc=2;
    flow1->x=5*WIDTH/8;
        nupdate();
        break;
    }
    case Qt::Key_F://消除第4个轨道上的小方块
    {
        dirc=3;
    flow1->x=7*WIDTH/8;
        nupdate();
        break;
    }
        default:;
    }
}
void playtwo::start()
{
    flow1->start();
}
