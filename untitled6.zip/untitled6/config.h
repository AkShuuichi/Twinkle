#ifndef CONFIG_H
#define CONFIG_H
#define WIDTH 1420
#define LENGTH 802
#define tap 5
#define COUNT2 175
#define COUNT 210
#define WIDTH3 1600
#define WIDTH2 1600
#define left 1440
#define top 100
#define bottom 650
#endif // CONFIG_H

