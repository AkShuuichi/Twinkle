#include "flower.h"
#include <QPainter>

Flower::Flower(double xx, double yy)
{
    x=xx,y=yy;
    pixindex=0;
    isStart=false;
    pixes[0]=QPixmap(":/new/prefix1/bm/flow1.png");
    pixes[1]=QPixmap(":/new/prefix1/bm/flow2.png");
    pixes[2]=QPixmap(":/new/prefix1/bm/flow3.png");
    startTimer(100);
}
Flower::~Flower(){}
void Flower::start()
{
    isStart=true;
    pixindex=0;
}

void Flower::draw(QPainter *paint)
{
    if (isStart)
    {
        paint->drawPixmap(x,y,100,70,pixes[pixindex]);
    }
}
void Flower::timerEvent(QTimerEvent *)
{
    if (!isStart) return;
    pixindex++;
    if (pixindex==3) isStart=false;
}
