#ifndef ENDING_H
#define ENDING_H
#include <QMainWindow>
#include<QPainter>
#include<QPushButton>
#include<QFont>
class ending : public QMainWindow
{
    Q_OBJECT
public:
    explicit ending(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
    QPushButton *exit,* onemore;
signals:

public slots:
    void Exit();
};

#endif // ENDING_H
