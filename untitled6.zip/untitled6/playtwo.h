#ifndef PLAYTWO_H
#define PLAYTWO_H
#include"ending.h"
#include <QMainWindow>
#include <QProgressBar>
#include<flower.h>
#include <QtMultimedia>
class playtwo : public QMainWindow
{
    Q_OBJECT
public:
    explicit playtwo(QWidget *parent = nullptr);
     void paintEvent(QPaintEvent *);
     void timerEvent(QTimerEvent *);
     int dirc;
     QProgressBar *pro2;
     void nupdate();
     void keyPressEvent(QKeyEvent *event);
     ending *ending2=NULL;
      QMediaPlayer *startSound2;
     Flower *flow1;
     QMediaPlayer *startSound4;
     void start();
signals:

public slots:
};

#endif // PLAYTWO_H
