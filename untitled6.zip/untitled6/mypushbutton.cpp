#include "mypushbutton.h"
#include<QDebug>
//MyPushButton::MyPushButton(QWidget *parent) : QPushButton(parent)
//{

//}


MyPushButton::MyPushButton(QString normalImg,QString pressImg)
{
    this->normalImgPath=normalImg;
    this->pressImgPath=pressImg;

    QPixmap pix;
    bool ret=pix.load(normalImg);
    if(!ret)
    {
        qDebug()<<"图片加载失败";
                  return ;
    }

    //矩形大小
    this->setFixedSize(400,400);
    //去掉矩形
    this->setStyleSheet("QPushButton{border:0px;}");
    //显示图标
    this->setIcon(pix);
    //图标大小
    this->setIconSize(QSize(200,200));

}
