#include "playone.h"
#include <QMenuBar>
#include<QPainter>
#include<QDebug>
#include "mainwindow.h"
#include<QPixmap>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<QObject>
#include<conio.h>
#include<QKeyEvent>
#include<QTimer>
#include <QMediaPlayer>
#include <QAction>
#include<QMenuBar>
#include"mypushbutton.h"
#include"config.h"
#include"chooselevelscene.h"
#include<QFont>
#include<QColor>
ChooseLevelScene *p3=NULL;
using namespace std;
const int HEIGHT=20;
const double v=30;
int score1;
int control1=1;
int j=0;
int d=0;
int w1;
int flag=1;
int slide1=0;
class Note1
{
public:
    double x,y;
    int color,z,height;
    Note1(double a,double b,int d)
    {
        x=a;
        y=b;
        color=d;
    }
    Note1(){}
    ~Note1(){}
};
Note1 note1[COUNT];


//函数:返回0-3的一个随机数
int setposition1()
{
    int pos=qrand()%4;//[(int)qrand() % 4]是一个从0到3的随机索引
    return pos;
}


playone::playone(QWidget *parent) : QMainWindow(parent)
{
    //配置第一个音乐场景
    //界面的大小
    this->setFixedSize(QSize(WIDTH3,LENGTH));
    //左上角图标
    this->setWindowIcon(QPixmap(":/new/prefix1/bm/b4837f277966730c5e64c2ea6bfc9d2f.jpg") );
    //左上角标题
    this->setWindowTitle("音乐场景1");



    startSound1=new QMediaPlayer(this);
    startSound1->setMedia(QUrl("qrc:/new/prefix1/bm/2.mp3"));
    startSound1->setVolume(80);  //音量
    startSound1->play();

    srand(time(NULL));
    startTimer(50);

    //为每个对象的坐标赋值
    for(int i=1;i<COUNT;i++)
    {
        int s=setposition1();//x是0~3的一个随机数
        note1[i].x=s*WIDTH/4;
         note1[i].z=s;
         note1[i].height=qrand()%40;
         note1[0].y=-10;
         if(i<9)
         note1[i].y=note1[i-1].y-v*7.5;
         if(i>=9&&i<15)
             note1[i].y=note1[i-1].y-v*6;
         if(i>=15&&i<93)
             note1[i].y=note1[i-1].y-v*(4);
          if(i>=93&&i<130){
             note1[i].y=note1[i-1].y-v*3;
         }
          if(i>=130)
             note1[i].y=note1[i-1].y-v*4;
    }
    star1=new Star(10,LENGTH*0.65);
    pro1=new QProgressBar(this);
    startSound3=new QMediaPlayer(this);
        QString sll = "QProgressBar::chunk:horizontal{background:rgb(176,196,222,200);}";
        pro1->setStyleSheet(sll);
        pro1->setRange(0,1000);
        pro1->setTextVisible(false);
        pro1->move(0,0);
        pro1->setFixedSize(WIDTH,LENGTH/40);
        pro1->show();

    QPushButton *backBtn1=new QPushButton(this);
        backBtn1->resize(100,100);
        backBtn1->move(left,bottom);
        backBtn1->setText("返回");
        connect(backBtn1,&QPushButton::clicked,[=](){
            //进入游戏场景
            this->hide();
            p3=new ChooseLevelScene();
            p3->show();
            startSound1->pause();
        });
}


//关卡的背景设置，重写一个画图函数
void playone::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/new/prefix1/bm/20210712103250.jpg");
    painter.drawPixmap(0,0,WIDTH,LENGTH,pix);
    QFont font;
    font.setPixelSize(30);
    font.setBold(true);
    painter.setFont(font);
    painter.setPen(Qt::red);
    QString str;
    str.sprintf("%d",score1);
    painter.drawText(left,top,str);
    str.sprintf("SCORE");
    painter.drawText(left,50,str);
    //画竖线
    star1->draw(&painter);
    painter.setPen(Qt::white);
    for(int i=1;i<4;i++)
    {
        painter.drawLine(i*WIDTH/4,0,i*WIDTH/4,LENGTH);
    }
    painter.drawLine(0,LENGTH*0.75,WIDTH,LENGTH*0.75);
    if(control1==1)
        {
          for(int i=1;i<=j;i++)
             {
                note1[i].y+=v;
                QColor color("white");
                color.setAlpha(100);
                 painter.setBrush(color);
                painter.drawRect(QRect(note1[i].x,note1[i].y,WIDTH/4,HEIGHT+note1[i].height));
             }
        }
     else
    {
        for(int i=1;i<=j;i++)
            {
                if(i!=w1)
                {
                    painter.setBrush(Qt::white);
                    note1[i].y+=25;
                    if(note1[i].y>=0)
                       { QColor color("white");
                        color.setAlpha(100);
                         painter.setBrush(color);
                   painter.drawRect(QRect(note1[i].x,note1[i].y,WIDTH/4,HEIGHT+note1[i].height));}
                    else {
                        continue;
                    }
                }
                 else
                {
                    QColor color("white");
                    color.setAlpha(100);
                     painter.setBrush(color);
                     painter.drawRect(QRect(note1[w1].x-WIDTH*2,note1[w1].y+HEIGHT,WIDTH/4,note1[w1].height));
                }
                control1=1;
            }
    }
    if(note1[COUNT-1].y>LENGTH||note1[COUNT-1].x>WIDTH)
    {
        this->close();
        ending1=new ending();
        ending1->show();
        delete star1;
        delete startSound3;
        delete pro1;
    }



}

void playone::timerEvent(QTimerEvent *)
{
     while(j<(COUNT-1))
    {
        j++;
        break;
    }
     slide1++;
     pro1->setValue(slide1);
    update();

}

void playone::nupdate()
{
    int i=1;
    for(;i<=j;i++)
    {
        if(note1[i].z==dirc)
        {
            if(note1[i].y>=LENGTH*0.65&&note1[i].y<LENGTH*0.85&&note1[i].x<WIDTH)
              {
                note1[i].x+=WIDTH*2;
                    w1=i;
                    control1=3;

                    startSound3->setMedia(QUrl("qrc:/new/prefix1/bm/boom.mp3"));
                    startSound3->setVolume(400);  //音量
                    startSound3->play();
                    star1->start();
                    update();
                    score1++;

                }
        }
    }
}

void playone::keyPressEvent(QKeyEvent *event)//键盘事件
{

    QKeyEvent *key=(QKeyEvent*)event;
    switch(key->key())
    {
    case Qt::Key_A://消除第一个轨道上的小方块
    {
        dirc=0;
        star1->x=WIDTH/8;
        nupdate();
        break;
    }
    case Qt::Key_S://消除第2个轨道上的小方块
    {
        dirc=1;
        star1->x=3*WIDTH/8;
        nupdate();
        break;
    }
    case Qt::Key_D://消除第3个轨道上的小方块
    {
        dirc=2;
       star1->x=5*WIDTH/8;
        nupdate();
        break;
    }
    case Qt::Key_F://消除第4个轨道上的小方块
    {
        dirc=3;
        star1->x=7*WIDTH/8;
        nupdate();
        break;
    }

        default:;
    }
}
void playone::start()
{
    star1->start();
}

