#include "ending.h"
#include"config.h"
#include<QPainter>
#include<QPushButton>
#include<QFont>
ending::ending(QWidget *parent) : QMainWindow(parent)
{
    this-> setFixedSize(WIDTH,LENGTH);
     this->setWindowTitle("音游");
     this->setWindowIcon(QIcon(":/new/prefix1/bm/b4837f277966730c5e64c2ea6bfc9d2f.jpg"));

    exit=new QPushButton(this);
    exit->resize(WIDTH/5,LENGTH/15);
    exit->move(QPoint(WIDTH/2.5,LENGTH/1.3));
    exit->setText("Exit");
    exit->setStyleSheet("background:white");
    exit->setStyleSheet("color:black");
    exit->setFont(QFont("Corbel Light",12,QFont::Bold));
    connect(exit,SIGNAL(clicked(bool)),this,SLOT(Exit()));

}
 void ending::paintEvent(QPaintEvent*e)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/new/prefix1/bm/OIP-C.jpg");
    painter.drawPixmap(0,0,WIDTH,LENGTH,pix);

   }
 void ending::Exit()
 {
     exit->hide();
     close();
 }


