#include "mainwindow.h"
#include "config.h"
#include<QPainter>
#include<iostream>
#include<QObject>
#include<QDebug>
#include <QAction>
#include<QMenuBar>
#include<QGraphicsEffect>
#include"mypushbutton.h"//引用一下自己写的

using namespace std;
const int HEIGHT=20;



//构造
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent)
{
  //1.设置界面固定大小
   this-> setFixedSize(WIDTH,LENGTH);
    this->setWindowTitle("音游");
    this->setWindowIcon(QIcon(":/new/prefix1/bm/b4837f277966730c5e64c2ea6bfc9d2f.jpg"));//开始界面左上角小图标
//buttons

        //放音乐
        startSound3=new QMediaPlayer(this);
        startSound3->setMedia(QUrl("qrc:/new/prefix1/bm/startmusic (2).mp3"));
        startSound3->setVolume(5000);  //音量
        startSound3->play();

        label=new QLabel(this);
        //QMovie *movie=new QMovie(":/new/prefix1/C:/Users/Administrator/Downloads/MixMeisterBPMAnalyzer/hecheng/资源/autom1.gif");
        QMovie *movie=new QMovie(":/new/prefix1/bm/20210712101914.gif");
        label->resize(WIDTH,LENGTH);
        label->setMovie(movie);
        movie->start();
        label->show();
        connect(label,SIGNAL(clicked(bool)),this,SLOT(Label()));

        start=new QPushButton(this);
        start->resize(WIDTH/5,LENGTH/15);
        start->move(QPoint(WIDTH/2.5,LENGTH/2.8));
        start->setText("START");
        start->setFont(QFont("Corbel Light",12,QFont::Bold));
        connect(start,SIGNAL(clicked(bool)),this,SLOT(Start()));

        exit=new QPushButton(this);
        exit->resize(WIDTH/5,LENGTH/15);
        exit->move(QPoint(WIDTH/2.5,LENGTH/1.8));
        exit->setText("Exit");
        exit->setFont(QFont("Corbel Light",12,QFont::Bold));
        connect(exit,SIGNAL(clicked(bool)),this,SLOT(Exit()));
        QGraphicsOpacityEffect *opacityEffect=new QGraphicsOpacityEffect;
            start->setGraphicsEffect(opacityEffect);
            opacityEffect->setOpacity(0.45);

            QGraphicsOpacityEffect *opacityEffect1=new QGraphicsOpacityEffect;
            exit->setGraphicsEffect(opacityEffect1);
            opacityEffect1->setOpacity(0.45);

}

void MainWindow::paintEvent(QPaintEvent *e)
{
    QPainter paint(this);

    //画框架：1000*800
    paint.setBrush(Qt::white);
    paint.drawRect(QRect(0,0,WIDTH,LENGTH));

}

MainWindow:: ~MainWindow()
{
    delete start;
    delete exit;
}

void MainWindow::Start()
{
    exit->hide();
    start->hide();
    label->hide();
    Choose();
    startSound3->stop();
    this->close();
    //4.完成功能：点击中间的开始按钮，能进入下一个选择的关卡（choosescene）

}

void MainWindow::Exit()
{
    start->hide();
    exit->hide();
    close();
}

void MainWindow::Label()
{
    start->hide();
    exit->hide();
}

void MainWindow::Choose()
{
    chooseScene=new ChooseLevelScene;
    chooseScene->show();
}























