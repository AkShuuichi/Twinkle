#ifndef CHOOSELEVELSCENE_H
#define CHOOSELEVELSCENE_H

#include <QMainWindow>
#include "playone.h"
#include "playtwo.h"
#include <QtMultimedia>

class ChooseLevelScene : public QMainWindow
{
    Q_OBJECT
public:
    explicit ChooseLevelScene(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
    playone *p1=NULL;
    playtwo *p2=NULL;
    QMediaPlayer *startSound;



signals:

public slots:
};

#endif // CHOOSELEVELSCENE_H
