#ifndef PLAYONE_H
#define PLAYONE_H
#include<QDebug>
#include <QMainWindow>
#include"ending.h"
#include<QFont>
#include <QProgressBar>
#include<star.h>
#include <QtMultimedia>

class playone : public QMainWindow
{
    Q_OBJECT
public:
    explicit playone(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
    void timerEvent(QTimerEvent *);
    int dirc;
    QProgressBar *pro1;
    QMediaPlayer *startSound3;
    void nupdate();
     QMediaPlayer *startSound1;
    void keyPressEvent(QKeyEvent *event);
    ending *ending1=NULL;
    Star *star1;
    void start();

signals:

public slots:
};

#endif // PLAYONE_H
