#include "star.h"
#include <QPainter>

Star::Star(double xx, double yy)
{
    x=xx,y=yy;
    pixindex=0;
    isStart=false;
    pixes[0]=QPixmap(":/new/prefix1/bm/twinkle1.png");
    pixes[1]=QPixmap(":/new/prefix1/bm/twinkle2.png");
    pixes[2]=QPixmap(":/new/prefix1/bm/twinkle3.png");
    startTimer(100);
}
Star::~Star()
{

}
void Star::start()
{
    isStart=true;
    pixindex=0;
}
void Star::draw(QPainter *paint)
{
    if (isStart)
    {
        paint->drawPixmap(x,y,100,70,pixes[pixindex]);
    }
}
void Star::timerEvent(QTimerEvent *)
{
    if (!isStart) return;
    pixindex++;
    if (pixindex==3) isStart=false;
}
